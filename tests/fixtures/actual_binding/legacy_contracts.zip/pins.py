"""Fixed read-only identities, not dynamic preflight or execution authority."""

from dataclasses import dataclass

IMPLEMENTATION = "eb305bfa373d92669217617bcdf667798118d0d8"
MEANING = "CONTENT_IDENTITY_ONLY_NOT_AUTHENTICITY_OR_AUTHORITY"
PERMISSIONS = tuple(
    (name, False)
    for name in (
        "build_execution_allowed",
        "promotion_authorized",
        "runtime_qualified",
        "device_class_qualified",
        "policy_adopted",
        "candidate_generation_allowed",
        "application_authorized",
        "runtime_accepted",
        "owner_proposal_allowed",
    )
)
ASSETS = (
    ("source_revision", "2481b84405beda95a394d1ca0248d7c9d632d28b"),
    ("source_manifest_digest", "1255f050f56240afe14d4fa7479692ed07b00bf59a6396fa6919354d07ace166"),
    ("probe_sha256", "0eb1891fe5c25a04e5447c637f81fb86a80404efbf8602b1ea31bf4d6a342f41"),
    ("vm_cohort_digest", "d98a259c5a45b56811d40a94e23e50a51ee88b513bb632396f45da6017f7af0c"),
    ("kernel_sha256", "8d8530d93852968b43c50a11a6c571628e16c074194bc3d293f64871e64e5475"),
    ("kernel_config_sha256", "3540f9dc8a7e48ef1d2e7b945a87976cf292f736d297cfebe3ac5cdf8571ee1e"),
    (
        "transport_profile_digest",
        "14a81e3410df2b8fef3cd5ed2850e19f5420558e8d718956fbe0c35f08dcf41c",
    ),
)


@dataclass(frozen=True, slots=True)
class CaseSpec:
    case: str
    expected: tuple[int, ...]
    installed: tuple[int, ...]
    kind: str
    decision: str
    causes: tuple[int, ...]
    init: str
    image: str


CASES = (
    CaseSpec(
        "DFD01",
        (0,),
        (0, 3),
        "DENY",
        "UNEXPECTED_FD",
        (3,),
        "9718be463cb86b409304aa1ed9c5df789a55f89e4dad96dd6d8a240e05168af8",
        "77765d55ad8f660e06fc3f92b9fe7944da262335fbc1d8cea9693dda4b357700",
    ),
    CaseSpec(
        "DFD02",
        (0,),
        (0,),
        "RESULT",
        "NO_DENIAL",
        (),
        "9ca4161d3e49910667675aecc95864237d5cf54d77b2c68229f05e806cb4c03e",
        "f68b437aeca678c7afef61b6905c05885ee764c65b6dc6f94731fea448d1bd6e",
    ),
    CaseSpec(
        "DFD03",
        (3,),
        (0, 3),
        "DENY",
        "UNEXPECTED_FD",
        (0,),
        "d05464ffcef304625917e126b7d6aa546b1ad71487d83d3a08761748fc8638dc",
        "6e4c54aaa945886d85f402ce49b07513ceacf54da07ab8e0f52f47e233b6efe1",
    ),
    CaseSpec(
        "DFD04",
        (0,),
        (0, 3, 4),
        "DENY",
        "UNEXPECTED_FD",
        (3, 4),
        "c5f842e47d8694893c4511775ef81c3ecfeb6b93074760ca87ce17177249ac22",
        "72d1521f3a09880abc8703fcf2372da1d8d05732489f66520ce8e98c910a0709",
    ),
    CaseSpec(
        "DFD05",
        (0,),
        (),
        "RESULT",
        "UNSUPPORTED_MISSING",
        (),
        "97f4290c6726628695ad3dd7c5793040577f12da468421bcfa8822e8bbd374c7",
        "85b3a98280a1a2772a6fb4c5422ed93829947c19a83a3c10228240e335b72ebc",
    ),
    CaseSpec(
        "DFD06",
        (0,),
        (3,),
        "RESULT",
        "UNSUPPORTED_MIXED",
        (),
        "3c944da856413b5cb4c165d99f9a8c56368bfb4aa80f0ec4eb9cb3eb022f20aa",
        "5061993e2d44362744de4a9f55debdef1fcb0abd41787de1a7aea68614f9a309",
    ),
)

VM = "/workspace/scratch/qemu-vm.Hkx9tc/sysroot"


def expected_argv(directory: str) -> tuple[str, ...]:
    libraries = VM + "/usr/lib/x86_64-linux-gnu"
    return (
        libraries + "/ld-linux-x86-64.so.2",
        "--library-path",
        libraries,
        VM + "/usr/bin/qemu-system-x86_64",
        "-no-user-config",
        "-nodefaults",
        "-machine",
        "pc-q35-10.0",
        "-accel",
        "tcg,thread=single",
        "-cpu",
        "qemu64",
        "-smp",
        "1",
        "-m",
        "768M",
        "-L",
        VM + "/usr/share/qemu",
        "-bios",
        VM + "/usr/share/seabios/bios-256k.bin",
        "-display",
        "none",
        "-monitor",
        "none",
        "-serial",
        "stdio",
        "-nic",
        "none",
        "-audiodev",
        "none,id=audio0",
        "-kernel",
        VM + "/boot/vmlinuz-6.12.113+deb13-cloud-amd64",
        "-initrd",
        directory + "/initrd.cpio.gz",
        "-append",
        "console=ttyS0 rdinit=/init panic=-1 oops=panic "
        "lsm=landlock,lockdown,yama,integrity,apparmor,bpf",
        "-no-reboot",
        "-chardev",
        "pipe,id=telemetry,path=" + directory + "/telemetry",
        "-device",
        "isa-serial,index=1,chardev=telemetry",
    )
