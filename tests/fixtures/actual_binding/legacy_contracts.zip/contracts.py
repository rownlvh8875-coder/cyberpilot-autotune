"""Immutable bytes and reference context; none of these objects grants authority."""

import re
from dataclasses import dataclass

DOCUMENT_ROLES = (
    "plan",
    "command",
    "preflight",
    "intent",
    "intent_checkpoint",
    "exit",
    "exit_checkpoint",
    "manifest",
    "report",
    "gate",
    "gate_checkpoint",
)
PAYLOAD_ROLES = ("stdout", "stderr", "telemetry", "console")
MODE = "SYNTHETIC_DIAGNOSTIC_FIXTURE"
IMPLEMENTATION = "eb305bfa373d92669217617bcdf667798118d0d8"
SOURCE = "2481b84405beda95a394d1ca0248d7c9d632d28b"
CLOCK = "MODELED_HOST_MONOTONIC_NS"
ORIGIN = "SYNTHETIC_NO_COMMAND_NOT_ATTESTED"
PERMISSIONS = tuple(
    (name, False)
    for name in (
        "build_execution_allowed",
        "promotion_authorized",
        "runtime_qualified",
        "device_class_qualified",
        "policy_adopted",
        "candidate_generation_allowed",
        "application_authorized",
        "runtime_accepted",
        "owner_proposal_allowed",
    )
)


def hex_id(value: object, width: int) -> bool:
    return type(value) is str and re.fullmatch("[0-9a-f]{" + str(width) + "}", value) is not None


@dataclass(frozen=True, slots=True)
class ReferenceExpectation:
    run_id: str
    attempt_id: str
    case: str
    clock_cohort_sha256: str
    plan_sha256: str
    command_sha256: str
    preflight_sha256: str

    def __post_init__(self) -> None:
        if not hex_id(self.run_id, 32) or not hex_id(self.attempt_id, 32):
            raise ValueError("exact immutable run/attempt IDs required")
        if type(self.case) is not str or self.case not in tuple(f"DFD{i:02}" for i in range(1, 7)):
            raise ValueError("fixed case required")
        for value in (
            self.clock_cohort_sha256,
            self.plan_sha256,
            self.command_sha256,
            self.preflight_sha256,
        ):
            if not hex_id(value, 64):
                raise ValueError("exact immutable context digest required")


@dataclass(frozen=True, slots=True)
class ReceiptBundle:
    documents: tuple[tuple[str, bytes], ...]
    payloads: tuple[tuple[str, bytes], ...]
    retained_anchor: str | None = None

    def __post_init__(self) -> None:
        for pairs in (self.documents, self.payloads):
            if type(pairs) is not tuple or any(
                type(pair) is not tuple
                or len(pair) != 2
                or type(pair[0]) is not str
                or type(pair[1]) is not bytes
                for pair in pairs
            ):
                raise ValueError("deep immutable named byte tuples required")
        if self.retained_anchor is not None and not hex_id(self.retained_anchor, 64):
            raise ValueError("anchor is an explicit optional content digest")


@dataclass(frozen=True, slots=True)
class BindingDecision:
    state: str
    reasons: tuple[str, ...]
    input_digest: str | None = None
    anchor_status: str = "NOT_VERIFIED"

    def __post_init__(self) -> None:
        if type(self.state) is not str or self.state not in ("BINDING_ONLY_CONSISTENT", "REJECTED"):
            raise ValueError("explicit structural outcome required")
        if type(self.reasons) is not tuple or any(type(value) is not str for value in self.reasons):
            raise ValueError("deep immutable reason tuple required")
        if bool(self.reasons) != (self.state == "REJECTED"):
            raise ValueError("reasons must match rejection")
        if self.input_digest is not None and not hex_id(self.input_digest, 64):
            raise ValueError("optional input content digest required")
        if type(self.anchor_status) is not str or self.anchor_status not in (
            "NOT_VERIFIED",
            "UNANCHORED_SUPPLIED_CHAIN_ONLY",
            "MATCHES_CALLER_RETAINED_ANCHOR",
        ):
            raise ValueError("explicit anchor limitation required")

    @property
    def status(self) -> str:
        return "BLOCKED"

    @property
    def content_status(self) -> str:
        return "NOT_EVALUATED"

    @property
    def history_status(self) -> str:
        return "UNAVAILABLE"

    @property
    def execution_status(self) -> str:
        return "SYNTHETIC_NO_COMMAND"

    @property
    def permissions(self) -> tuple[tuple[str, bool], ...]:
        return PERMISSIONS
