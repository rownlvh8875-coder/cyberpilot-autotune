"""Exact immutable synthetic comparison envelopes; no execution or application authority."""

from dataclasses import dataclass

from content import SavedEvidence, Verdict
from contracts import PERMISSIONS, BindingDecision, ReceiptBundle, ReferenceExpectation, hex_id

ROLES = (
    "telemetry",
    "console",
    "cli_stdout",
    "cli_stderr",
    "record_json",
    "initrd",
    "exit_receipt",
)
REASONS = (
    "INPUT_LIMIT",
    "ROLE_SET_INVALID",
    "LEGACY_INPUT_NOT_SUPPORTED",
    "ORIGIN_UNSUPPORTED",
    "CASE_CONTEXT_INVALID",
    "COMPARISON_REFERENCE_MISMATCH",
    "COMPARISON_ENCODING_INVALID",
    "COMPARISON_JSON_INVALID",
    "COMPARISON_NONCANONICAL",
    "COMPARISON_SHAPE_INVALID",
    "COMPARISON_CONTEXT_MISMATCH",
    "BINDING_REJECTED",
    "BINDING_DIGEST_MISMATCH",
    "INPUT_DESCRIPTOR_MISMATCH",
    "SNAPSHOT_DIGEST_MISMATCH",
    "SHARED_PAYLOAD_MISMATCH",
    "MODEL_IMAGE_CONTEXT_MISMATCH",
)


@dataclass(frozen=True, slots=True)
class SevenInputBundle:
    evidence: SavedEvidence
    binding_bundle: ReceiptBundle
    comparison_receipt: bytes

    def __post_init__(self) -> None:
        if (
            type(self.evidence) is not SavedEvidence
            or type(self.binding_bundle) is not ReceiptBundle
            or type(self.comparison_receipt) is not bytes
        ):
            raise ValueError("exact immutable evidence, receipt bundle and bytes required")


@dataclass(frozen=True, slots=True)
class SevenInputReference:
    binding_reference: ReferenceExpectation
    comparison_receipt_sha256: str

    def __post_init__(self) -> None:
        if type(self.binding_reference) is not ReferenceExpectation or not hex_id(
            self.comparison_receipt_sha256, 64
        ):
            raise ValueError("exact immutable reference and content root required")


@dataclass(frozen=True, slots=True)
class SevenInputDecision:
    full_input_binding_status: str
    reasons: tuple[str, ...]
    represented_roles: tuple[str, ...] = ()
    present_roles: tuple[str, ...] = ()
    unavailable_roles: tuple[str, ...] = ()
    snapshot_sha256: str | None = None
    comparison_input_sha256: str | None = None
    binding: BindingDecision | None = None
    content: Verdict | None = None

    def __post_init__(self) -> None:
        if type(
            self.full_input_binding_status
        ) is not str or self.full_input_binding_status not in (
            "SEVEN_PRESENT_INPUTS_BOUND",
            "EXPLICIT_UNAVAILABLE_EXIT_BOUND",
            "REJECTED",
        ):
            raise ValueError("explicit structural outcome required")
        if type(self.reasons) is not tuple or any(
            type(reason) is not str or reason not in REASONS for reason in self.reasons
        ):
            raise ValueError("immutable known reason tuple required")
        if any(
            type(roles) is not tuple or any(type(role) is not str for role in roles)
            for roles in (self.represented_roles, self.present_roles, self.unavailable_roles)
        ):
            raise ValueError("immutable role tuples required")
        if (
            self.binding is not None
            and type(self.binding) is not BindingDecision
            or self.content is not None
            and type(self.content) is not Verdict
        ):
            raise ValueError("exact immutable child results required")
        if self.full_input_binding_status == "REJECTED":
            if (
                len(self.reasons) != 1
                or self.represented_roles
                or self.present_roles
                or self.unavailable_roles
                or self.snapshot_sha256 is not None
                or self.comparison_input_sha256 is not None
                or self.content is not None
            ):
                raise ValueError(
                    "rejected comparison has no claimed roles, new digests or content evaluation"
                )
        else:
            present = (
                ROLES
                if self.full_input_binding_status == "SEVEN_PRESENT_INPUTS_BOUND"
                else ROLES[:-1]
            )
            unavailable = (
                ()
                if self.full_input_binding_status == "SEVEN_PRESENT_INPUTS_BOUND"
                else ("exit_receipt",)
            )
            if (
                self.reasons
                or self.represented_roles != ROLES
                or self.present_roles != present
                or self.unavailable_roles != unavailable
                or not hex_id(self.snapshot_sha256, 64)
                or not hex_id(self.comparison_input_sha256, 64)
                or self.binding is None
                or self.binding.state != "BINDING_ONLY_CONSISTENT"
                or self.content is None
            ):
                raise ValueError(
                    "bound snapshot requires complete role identities and actual child results"
                )

    @property
    def binding_evaluation_status(self) -> str:
        return "NOT_EVALUATED_STRUCTURAL_REJECTION" if self.binding is None else "EVALUATED"

    @property
    def content_evaluation_status(self) -> str:
        return "NOT_EVALUATED_STRUCTURAL_REJECTION" if self.content is None else "EVALUATED"

    @property
    def status(self) -> str:
        return "BLOCKED"

    @property
    def history_status(self) -> str:
        return "UNAVAILABLE"

    @property
    def execution_status(self) -> str:
        return "SYNTHETIC_NO_COMMAND"

    @property
    def integrated_admission(self) -> bool:
        return False

    @property
    def semantic_cohort_status(self) -> str:
        return "NOT_ESTABLISHED_BY_SNAPSHOT_BINDING"

    @property
    def permissions(self) -> tuple[tuple[str, bool], ...]:
        return PERMISSIONS

    @property
    def digest_meaning(self) -> str:
        return "CONTENT_IDENTITY_ONLY_NOT_AUTHENTICITY_OR_AUTHORITY"
