"""Pure saved-content checks. No IO, producer, preflight or history qualification."""

import json
import re
from dataclasses import dataclass
from datetime import datetime
from hashlib import sha256
from pathlib import PurePosixPath
from typing import Any, NoReturn

from tests.deny_fd_v2.validation import check_inventory
from tests.deny_fd_v2.wire import decode

from pins import ASSETS, CASES, MEANING, PERMISSIONS, CaseSpec, expected_argv

JSON_LIMIT = 65536
STREAM_LIMIT = 1048576
IMAGE_LIMIT = 4 * 1024 * 1024
ROLES = (
    "telemetry",
    "console",
    "cli_stdout",
    "cli_stderr",
    "record_json",
    "initrd",
    "exit_receipt",
)


@dataclass(frozen=True, slots=True)
class SavedEvidence:
    case: str
    case_directory: str
    telemetry: bytes
    console: bytes
    cli_stdout: bytes
    cli_stderr: bytes
    record_json: bytes
    initrd: bytes
    exit_receipt: bytes | None = None
    origin: str = "LEGACY_SAVED_CONTENT_ONLY"

    def __post_init__(self) -> None:
        if any(type(value) is not str for value in (self.case, self.case_directory, self.origin)):
            raise ValueError("immutable string identities required")
        for role in ROLES:
            value = getattr(self, role)
            if not (type(value) is bytes or role == "exit_receipt" and value is None):
                raise ValueError("immutable bytes required")


@dataclass(frozen=True, slots=True)
class Verdict:
    case: str
    origin: str
    content_status: str
    reasons: tuple[str, ...]
    input_manifest_sha256: str | None = None
    observed_fds: tuple[int, ...] = ()
    decision_value: str | None = None
    cli_returncode: int | None = None
    warnings: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if any(type(value) is not str for value in (self.case, self.origin, self.content_status)):
            raise ValueError("immutable verdict identities required")
        if any(
            value is not None and type(value) is not str
            for value in (self.input_manifest_sha256, self.decision_value)
        ):
            raise ValueError("immutable optional verdict identities required")
        if self.cli_returncode is not None and type(self.cli_returncode) is not int:
            raise ValueError("explicit optional integer returncode required")
        if any(
            type(value) is not tuple for value in (self.reasons, self.warnings, self.observed_fds)
        ):
            raise ValueError("immutable verdict tuples required")
        if any(type(value) is not str for value in self.reasons + self.warnings):
            raise ValueError("immutable verdict reasons required")
        if any(type(value) is not int for value in self.observed_fds):
            raise ValueError("immutable integer FD values required")

    @property
    def status(self) -> str:
        return "BLOCKED"

    @property
    def history_status(self) -> str:
        return "UNAVAILABLE"

    @property
    def permissions(self) -> tuple[tuple[str, bool], ...]:
        return PERMISSIONS

    @property
    def digest_meaning(self) -> str:
        return MEANING


class Rejected(ValueError):
    """Stable reason for this verifier's read-only structural rejection."""


def need(condition: bool, reason: str) -> None:
    if not condition:
        raise Rejected(reason)


def canonical(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def digest(raw: bytes) -> str:
    return sha256(raw).hexdigest()


def _invalid(value: str) -> NoReturn:
    raise ValueError("float/nonfinite forbidden")


def _unique(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for key, value in pairs:
        need(key not in out, "DUPLICATE_JSON_KEY")
        out[key] = value
    return out


def _json(raw: bytes) -> dict[str, Any]:
    try:
        value = json.loads(
            raw, object_pairs_hook=_unique, parse_float=_invalid, parse_constant=_invalid
        )
    except Rejected:
        raise
    except (ValueError, UnicodeError, RecursionError) as error:
        raise Rejected("MALFORMED_JSON") from error
    need(type(value) is dict, "JSON_OBJECT_REQUIRED")
    assert isinstance(value, dict)
    return value


def _shape(value: Any, keys: str, reason: str) -> None:
    need(type(value) is dict and set(value) == set(keys.split()), reason)


def _equal(value: Any, expected: Any, reason: str) -> None:
    need(canonical(value) == canonical(expected), reason)


def _uint(value: Any) -> bool:
    return type(value) is int and 0 <= value < 2**64


def _record(record: Any, evidence: SavedEvidence, spec: CaseSpec) -> None:
    keys = """schema case attempt_id source_revision source_manifest_digest probe_sha256
    vm_cohort_digest kernel_sha256 kernel_config_sha256 transport_profile_digest init_sha256
    image_sha256 argv host_start_ns host_end_ns clock_domain status permissions digest_meaning
    telemetry console exit_code termination collector_error"""
    _shape(record, keys, "RECORD_SHAPE_INVALID")
    expected = dict(ASSETS) | {
        "schema": "deny-fd-v2-dual-acquisition-v1",
        "case": spec.case,
        "init_sha256": spec.init,
        "image_sha256": spec.image,
        "clock_domain": "HOST_MONOTONIC_NS",
        "status": "BLOCKED",
        "permissions": dict(PERMISSIONS),
        "digest_meaning": MEANING,
        "exit_code": 0,
        "termination": "EXITED",
        "collector_error": None,
        "argv": list(expected_argv(evidence.case_directory)),
    }
    for key, wanted in expected.items():
        _equal(record[key], wanted, "RECORD_COHORT_OR_STAGE_MISMATCH")
    need(
        type(record["attempt_id"]) is str
        and re.fullmatch("[0-9a-f]{32}", record["attempt_id"]) is not None,
        "ATTEMPT_ID_INVALID",
    )
    need(_uint(record["host_start_ns"]) and _uint(record["host_end_ns"]), "HOST_CLOCK_INVALID")
    need(record["host_start_ns"] <= record["host_end_ns"], "HOST_CLOCK_ORDER_INVALID")
    for role in ("telemetry", "console"):
        stream = record[role]
        _shape(stream, "raw_sha256 raw_size complete error", "STREAM_SHAPE_INVALID")
        raw = getattr(evidence, role)
        _equal(
            stream,
            {"raw_sha256": digest(raw), "raw_size": len(raw), "complete": True, "error": None},
            "RAW_STREAM_MISMATCH",
        )
    need(digest(evidence.initrd) == spec.image, "IMAGE_CONTENT_MISMATCH")


def _exit(raw: bytes | None, case: str) -> int | None:
    if raw is None:
        return None
    receipt = _json(raw)
    _shape(
        receipt,
        "case cli_returncode observation recorded_at_utc trusted_launch_attestation",
        "EXIT_RECEIPT_SHAPE_INVALID",
    )
    need(
        receipt["case"] == case
        and type(receipt["cli_returncode"]) is int
        and receipt["cli_returncode"] == 2
        and receipt["trusted_launch_attestation"] is False,
        "EXIT_RECEIPT_INVALID",
    )
    need(
        receipt["observation"] == "execution-tool completed process exit result",
        "EXIT_RECEIPT_INVALID",
    )
    stamp = receipt["recorded_at_utc"]
    need(
        type(stamp) is str
        and re.fullmatch(r"\d{4}-\d\d-\d\d \d\d:\d\d:\d\d UTC", stamp) is not None,
        "EXIT_RECEIPT_INVALID",
    )
    try:
        # strptime lazily imports a stdlib module on first use (filesystem IO).
        # Shape is already fixed above; built-in datetime checks the calendar.
        datetime(
            int(stamp[0:4]),
            int(stamp[5:7]),
            int(stamp[8:10]),
            int(stamp[11:13]),
            int(stamp[14:16]),
            int(stamp[17:19]),
        )
    except ValueError as error:
        raise Rejected("EXIT_RECEIPT_INVALID") from error
    return 2


def _wire(raw: bytes, spec: CaseSpec) -> tuple[int, ...]:
    try:
        capture = decode(raw)
        decision = check_inventory(capture)
    except ValueError as error:
        raise Rejected("WIRE_INVALID") from error
    need(decision.outcome == "WIRE_DIAGNOSTIC_CONSISTENT", "INVENTORY_INVALID")
    events = capture.events
    assets = dict(ASSETS)
    need(
        events[0].values[2:4] == (assets["source_revision"], assets["source_manifest_digest"])
        and events[0].values[6] == spec.case,
        "WIRE_SOURCE_CASE_MISMATCH",
    )
    need(events[1].values == (1, spec.expected[0], 1), "POLICY_PROFILE_MISMATCH")
    observed = tuple(e.values[4] for e in events if e.kind == "FD")
    expected = tuple(e.values[1] for e in events if e.kind == "EXPECT")
    causes = tuple(e.values[1] for e in events if e.kind == "CAUSE")
    actual = next(e for e in events if e.kind in ("DENY", "RESULT"))
    need(
        (observed, expected, actual.kind, actual.values[5], causes)
        == (spec.installed, spec.expected, spec.kind, spec.decision, spec.causes),
        "SOURCE_PROFILE_MISMATCH",
    )
    return observed


def verify(evidence: SavedEvidence) -> Verdict:
    """Content consistency only. Unknown/future modes never inherit a legacy pass."""
    if type(evidence) is not SavedEvidence:
        raise ValueError("SavedEvidence required")
    manifest = None
    try:
        need(
            type(evidence.origin) is str
            and evidence.origin in ("LEGACY_SAVED_CONTENT_ONLY", "SYNTHETIC_SAVED_CONTENT_FIXTURE"),
            "UNSUPPORTED_ORIGIN",
        )
        need(type(evidence.case) is str, "CASE_INVALID")
        spec = next((spec for spec in CASES if spec.case == evidence.case), None)
        need(spec is not None, "CASE_INVALID")
        assert spec is not None
        directory = evidence.case_directory
        need(
            type(directory) is str
            and directory.startswith("/")
            and len(directory) <= 4096
            and ".." not in PurePosixPath(directory).parts
            and str(PurePosixPath(directory)) == directory
            and not any(char in directory for char in (",", "\0", "\r", "\n")),
            "CASE_PATH_INVALID",
        )
        need(len(evidence.telemetry) + len(evidence.console) <= STREAM_LIMIT, "INPUT_LIMIT")
        need(len(evidence.initrd) <= IMAGE_LIMIT, "INPUT_LIMIT")
        for role in ("cli_stdout", "cli_stderr", "record_json", "exit_receipt"):
            raw = getattr(evidence, role)
            need(raw is None or len(raw) <= JSON_LIMIT, "INPUT_LIMIT")
        identity = {
            role: None if (raw := getattr(evidence, role)) is None else digest(raw)
            for role in ROLES
        }
        manifest = digest(
            canonical(
                {
                    "origin": evidence.origin,
                    "case": evidence.case,
                    "case_directory": directory,
                    "inputs": identity,
                }
            )
        )
        cli, envelope = _json(evidence.cli_stdout), _json(evidence.record_json)
        need(cli.get("capture") == "RECORDED_UNTRUSTED", "CLI_CAPTURE_NOT_SUCCESS")
        _shape(cli, "capture status permissions records", "CLI_SHAPE_INVALID")
        _equal(cli["permissions"], dict(PERMISSIONS), "PERMISSIONS_INVALID")
        need(
            cli["status"] == "BLOCKED"
            and type(cli["records"]) is list
            and len(cli["records"]) == 1,
            "CLI_SHAPE_INVALID",
        )
        _shape(
            envelope,
            "record content_digest failure_reason acquisition_error "
            "persistence_error raw_write_outcomes",
            "ENVELOPE_SHAPE_INVALID",
        )
        need(
            all(
                envelope[key] is None
                for key in ("failure_reason", "acquisition_error", "persistence_error")
            ),
            "ACQUISITION_OR_PERSISTENCE_FAILED",
        )
        _equal(
            envelope["raw_write_outcomes"],
            {"telemetry.bin": "WRITTEN", "console.bin": "WRITTEN"},
            "RAW_PERSISTENCE_FAILED",
        )
        record = envelope["record"]
        _record(record, evidence, spec)
        _equal(cli["records"][0], record, "CLI_RECORD_MISMATCH")
        need(envelope["content_digest"] == digest(canonical(record)), "RECORD_DIGEST_MISMATCH")
        code = _exit(evidence.exit_receipt, evidence.case)
        observed = _wire(evidence.telemetry, spec)
        warnings: tuple[str, ...] = () if code is not None else ("CLI_EXIT_RECEIPT_UNAVAILABLE",)
        if evidence.cli_stderr:
            warnings += ("UNTRUSTED_STDERR_PRESENT",)
        return Verdict(
            evidence.case,
            evidence.origin,
            "CONSISTENT_SAVED_CONTENT",
            (),
            manifest,
            observed,
            spec.decision,
            code,
            warnings,
        )
    except Rejected as error:
        return Verdict(evidence.case, evidence.origin, "REJECTED", (str(error),), manifest)
